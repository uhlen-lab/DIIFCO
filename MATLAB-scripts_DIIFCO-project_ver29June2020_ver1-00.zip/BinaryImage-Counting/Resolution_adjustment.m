function F_XYZIDint_Space = Resolution_adjustment(F_XYZIDint, out_dir)

% Scripts for DIIFCO project by Uhlen lab
% Ver 1.00
% These scripts are written by Shigeaki Kanatani 
%
% Contact: Per Uhl�n, per.uhlen@ki.se
%          Shigeaki Kanatani, shigeaki.kanatani@ki.se

%% Summary 
 % Adjustment of pixel to actual volume
 % [0.585 0.585 5] is resolution specific to the COLM light sheet system
 % F_XYZIDint is arrary of X, Y, Z, ID, Intensity.
 
    F_XYZIDint_Space = F_XYZIDint;
    F_XYZIDint_Space(:,3) = F_XYZIDint_Space(:,3)*5;
    F_XYZIDint_Space(:,2) = F_XYZIDint_Space(:,2)*0.585;
    F_XYZIDint_Space(:,1) = F_XYZIDint_Space(:,1)*0.585;
    
    save([out_dir '\' 'F_XYZIDint_Space.mat'],'F_XYZIDint_Space');
    
    Header ={'X', 'Y', 'Z', 'ID', 'Intensity'};
    csvwrite_with_headers([out_dir '\' 'F_XYZIDint_Space.csv'], F_XYZIDint_Space, Header);
    
    pointData = F_XYZIDint_Space(:,1:3);
    save([out_dir '\' 'pointData.mat'],'pointData');
    
end